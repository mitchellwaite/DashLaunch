﻿namespace Dashlaunch_Translation_GUI
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearlist = new System.Windows.Forms.ToolStripMenuItem();
            this.loadorig = new System.Windows.Forms.ToolStripMenuItem();
            this.loadtranslation = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.savestrings = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadfile = new System.Windows.Forms.OpenFileDialog();
            this.savefile = new System.Windows.Forms.SaveFileDialog();
            this.items = new System.Windows.Forms.ListView();
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.originaltxt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.translationtxt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.itemname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.copybtn = new System.Windows.Forms.Button();
            this.savebtn = new System.Windows.Forms.Button();
            this.original = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.translation = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(950, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearlist,
            this.loadorig,
            this.loadtranslation,
            this.toolStripSeparator1,
            this.savestrings,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // clearlist
            // 
            this.clearlist.Name = "clearlist";
            this.clearlist.Size = new System.Drawing.Size(180, 22);
            this.clearlist.Text = "Clear list";
            this.clearlist.Click += new System.EventHandler(this.clearlist_Click);
            // 
            // loadorig
            // 
            this.loadorig.Image = ((System.Drawing.Image)(resources.GetObject("loadorig.Image")));
            this.loadorig.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.loadorig.Name = "loadorig";
            this.loadorig.Size = new System.Drawing.Size(180, 22);
            this.loadorig.Text = "Load Original";
            this.loadorig.Click += new System.EventHandler(this.loadorig_Click);
            // 
            // loadtranslation
            // 
            this.loadtranslation.Image = ((System.Drawing.Image)(resources.GetObject("loadtranslation.Image")));
            this.loadtranslation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.loadtranslation.Name = "loadtranslation";
            this.loadtranslation.Size = new System.Drawing.Size(180, 22);
            this.loadtranslation.Text = "Load Translation";
            this.loadtranslation.Click += new System.EventHandler(this.loadtranslation_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // savestrings
            // 
            this.savestrings.Image = ((System.Drawing.Image)(resources.GetObject("savestrings.Image")));
            this.savestrings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.savestrings.Name = "savestrings";
            this.savestrings.Size = new System.Drawing.Size(180, 22);
            this.savestrings.Text = "Save Changes to file";
            this.savestrings.Click += new System.EventHandler(this.savestrings_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // loadfile
            // 
            this.loadfile.DefaultExt = "resx";
            this.loadfile.Filter = "Resource files|*.resx|All Files|*.*";
            // 
            // savefile
            // 
            this.savefile.DefaultExt = "resx";
            this.savefile.Filter = "Resource files|*.resx|All Files|*.*";
            // 
            // items
            // 
            this.items.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.items.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.name,
            this.originaltxt,
            this.translationtxt});
            this.items.FullRowSelect = true;
            this.items.GridLines = true;
            this.items.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.items.Location = new System.Drawing.Point(12, 242);
            this.items.MultiSelect = false;
            this.items.Name = "items";
            this.items.Size = new System.Drawing.Size(924, 298);
            this.items.TabIndex = 5;
            this.items.UseCompatibleStateImageBehavior = false;
            this.items.View = System.Windows.Forms.View.Details;
            this.items.DoubleClick += new System.EventHandler(this.stringslist_DoubleClick);
            // 
            // name
            // 
            this.name.Text = "Name";
            // 
            // originaltxt
            // 
            this.originaltxt.Text = "Original Text";
            this.originaltxt.Width = 418;
            // 
            // translationtxt
            // 
            this.translationtxt.Text = "Translation Text";
            this.translationtxt.Width = 439;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.itemname);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.copybtn);
            this.groupBox1.Controls.Add(this.savebtn);
            this.groupBox1.Controls.Add(this.original);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.translation);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(924, 209);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Edit Selection";
            // 
            // itemname
            // 
            this.itemname.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.itemname.Location = new System.Drawing.Point(74, 180);
            this.itemname.Name = "itemname";
            this.itemname.Size = new System.Drawing.Size(162, 20);
            this.itemname.TabIndex = 11;
            this.itemname.TextChanged += new System.EventHandler(this.translation_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Name:";
            // 
            // copybtn
            // 
            this.copybtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.copybtn.Location = new System.Drawing.Point(242, 180);
            this.copybtn.Name = "copybtn";
            this.copybtn.Size = new System.Drawing.Size(335, 23);
            this.copybtn.TabIndex = 9;
            this.copybtn.Text = "Copy original to Translation";
            this.copybtn.UseVisualStyleBackColor = true;
            this.copybtn.Click += new System.EventHandler(this.copybtn_Click);
            // 
            // savebtn
            // 
            this.savebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.savebtn.Enabled = false;
            this.savebtn.Location = new System.Drawing.Point(583, 180);
            this.savebtn.Name = "savebtn";
            this.savebtn.Size = new System.Drawing.Size(335, 23);
            this.savebtn.TabIndex = 8;
            this.savebtn.Text = "Save changes/Add new item";
            this.savebtn.UseVisualStyleBackColor = true;
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // original
            // 
            this.original.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.original.Location = new System.Drawing.Point(74, 100);
            this.original.Multiline = true;
            this.original.Name = "original";
            this.original.ReadOnly = true;
            this.original.Size = new System.Drawing.Size(844, 74);
            this.original.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Original:";
            // 
            // translation
            // 
            this.translation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.translation.Location = new System.Drawing.Point(74, 19);
            this.translation.Multiline = true;
            this.translation.Name = "translation";
            this.translation.Size = new System.Drawing.Size(844, 74);
            this.translation.TabIndex = 5;
            this.translation.TextChanged += new System.EventHandler(this.translation_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Translation:";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 552);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.items);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Dashlaunch Translation GUI";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadtranslation;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog loadfile;
        private System.Windows.Forms.ToolStripMenuItem savestrings;
        private System.Windows.Forms.ToolStripMenuItem loadorig;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.SaveFileDialog savefile;
        private System.Windows.Forms.ListView items;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader originaltxt;
        private System.Windows.Forms.ColumnHeader translationtxt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox itemname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button copybtn;
        private System.Windows.Forms.Button savebtn;
        private System.Windows.Forms.TextBox original;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox translation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem clearlist;
    }
}

